package pdf.dudepdftools.interfaces;

public interface ItemSelectedListener {
    void isSelected(Boolean isSelected, int countFiles);
}