package pdf.dudepdftools.interfaces;

public interface DataSetChanged {
    void updateDataset();
}
