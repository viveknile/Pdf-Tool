package pdf.dudepdftools.interfaces;

public interface OnBackPressedInterface {
    void closeBottomSheet();
    boolean checkSheetBehaviour();
}
