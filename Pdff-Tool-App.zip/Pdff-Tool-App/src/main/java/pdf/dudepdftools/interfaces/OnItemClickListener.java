package pdf.dudepdftools.interfaces;

public interface OnItemClickListener {

    void onItemClick(int position);
}
