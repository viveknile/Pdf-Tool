package pdf.dudepdftools.interfaces;

import java.util.ArrayList;

public interface BottomSheetPopulate {
    void onPopulate(ArrayList<String> paths);
}
