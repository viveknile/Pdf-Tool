package pdf.dudepdftools.interfaces;

public interface OnTextToPdfInterface {
    void onPDFCreationStarted();
    void onPDFCreated(boolean success);
}
